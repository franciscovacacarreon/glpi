<?php
echo 'Access denied';
